char ext2_D [3] [4]; /* Try an external 2-D array */
